from flask import Flask, render_template, request, redirect
app = Flask(__name__)

@app.route('/')
def dojosurvey():
    return render_template('index.html')

@app.route('/results', methods=['POST'])
def results():
    print request.form
    return render_template('results.html')


app.run(debug=True)